kubectl create -f crds.yaml
kubectl apply -f operator.yaml