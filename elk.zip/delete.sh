#!/bin/bash
kubectl get namespaces --no-headers -o custom-columns=:metadata.name \
  | xargs -n1 kubectl delete elastic --all -n
kubectl delete -f operator.yaml
kubectl delete -f crds.yaml
kubectl delete pvc --all -n elastic-system
kubectl delete pv --all
echo ECK deleted
