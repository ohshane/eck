#!/bin/bash
watch -n 1 kubectl get pods -A
echo ECK deleted
