curl -O https://download.elastic.co/downloads/eck/1.9.1/crds.yaml
curl -O https://download.elastic.co/downloads/eck/1.9.1/operator.yaml